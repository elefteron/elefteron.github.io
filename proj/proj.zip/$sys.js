sys={p:"",os:"window$ 7",comp:"GA-P55A_W7-64", user:"elefter"};
