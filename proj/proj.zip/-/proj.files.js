proj.files/* [16] */=
["proj.files.js","proj.cmd"   ,"proj.hta","proj.htm","proj.js","proj.npp.ses"
,"proj.lst"     ,"proj.md5"   ,"proj.dif","proj.zip"
,"$sys.js"      ,"desktop.ini","proj-dmp.init.log","proj-dmp.menu.log","proj-dmp.syntax.log","proj.dif"
]
