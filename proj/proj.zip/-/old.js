		
// stackoverflow.com/questions/722668/traverse-all-the-nodes-of-a-json-object-tree-with-javascript
   
// if(p.length<=0) { alert('*.proj file miss! associate it with proj.cmd to send proj file as param.');
// } else {
   // log('<s'+'cript src="'+p+'"></s'+'cript>')
/* *-/ // --- get file by activex
      proj=getFile(p);
      if(dbg) dmp(proj);
      eval(proj);
/* */ 

// -- get file by html head script 
// -- stackoverflow.com/questions/14521108/dynamically-load-js-inside-js
//  var script = document.createElement('script');
//  script.type = 'text/javascript'; script.src = p;  
//  document.head.appendChild(script); // document.getElementsByTagName('head')[0].appendChild(script);
//  script.onload = function () {

//    set_proj(p); 
//	  a=traverse_(proj.actions); al=0; for (i in a) al++; // proj.actions=[{key:val}, ... ]
//	  dmp(dump()); 
/* *-/ 
    dmp('' // w3schools.com/js/js_window_navigator.asp
	// stackoverflow.com/questions/5916900/how-can-you-detect-the-version-of-a-browser
	   +"navigator.appName:"+navigator.appName +eol
	   +"navigator.appCodeName:" + navigator.appCodeName +eol
	   +"navigator.appVersion:" + navigator.appVersion +eol
	   +"(Engine) navigator.product:" + navigator.product +eol // undef
	   +"(Agent) navigator.userAgent:" + navigator.userAgent +eol
	   +"(os) navigator.platform:" + navigator.platform +eol
	)
/* */ 
