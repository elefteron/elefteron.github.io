load_new('scr/fontorg-info.js')
// ------------------------------
   prot='',prev=[];  
// ------------------------------
   projname='fo3';  
   projdir =proj_+projname+'.js/'
   run_dir =proj_+projname+'.js/'
   downdir =down_

   pr1='see:';  projfile=projdir+projname+' report.htm'// projdir+projfile
   pr2='run:';  run_file=run_dir+projname+'.hta'       // run_dir+run_file
   pr3='down:'; downfile=downdir+projname+'.zip'       // downdir+downfile
   
   prev[0]=prev_+projname+' cp.png' // prev_+projname+
   prev[1]=prev_+projname+' rep.png' // prev_+projname+
load_end()