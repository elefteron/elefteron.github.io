_load._new("fs-data.js"); 
   var timescan=[2013,4,7,22,50]; // by drvinfo
   var UserName="elefter"; 
   var ComputerName="RESET4"; 
   var root="D:\\WINDOWS"; 
   var os="Windows_NT"; 
   addDrv({'ord_':0,'drv':"D",free:16109899776,size:41940668416
         ,'volID':"HDS82-p1.rst4",'volSER':"B4CD-076F",fs:"NTFS" ,drvtype:"fixed"}) 
   addDrv({'ord_':1,'drv':"E",free: 1022779392,size:30038265856
         ,'volID':"HDS82-p2",     'volSER':"B4D3-F445",fs:"NTFS" ,drvtype:"fixed"}) 
   addDrv({'ord_':2,'drv':"F",free: 6338265088,size:10345472000
         ,'volID':"HDS82-P3",     'volSER':"9870-2A5D",fs:"FAT32",drvtype:"fixed"}) 
   addDrv({'ord_':3,'drv':"G",free:  620208128,size: 5239468032
         ,'volID':"S20-p1",       'volSER':"D450-6214",fs:"NTFS" ,drvtype:"fixed"}) 
   addDrv({'ord_':4,'drv':"H",free: 5254291456,size:14780792832
         ,'volID':"S20-P2",       'volSER':"8094-B598",fs:"NTFS" ,drvtype:"fixed"}) 
_load._end() 